<h1>
<?php
echo "Hello";
 ?>
</h1>